# Smart Health Monitoring System

This is a Java-based full stack project to monitor and store basic health metrics using JSP, Servlets, and MySQL.